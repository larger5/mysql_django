# -*- coding:utf-8 -*-
from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings    # 获取 settings.py 里边配置的信息
import os
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.core   import serializers

# 1.1.进入首页
def index(request):
    return render(request,"booktest/index.html")

# 2.GET 请求测试
def getTest(request):
    a=request.GET['a']
    b=request.GET['b']
    context = {'a': a, 'b': b}
    return render(request, 'booktest/showTest.html', context)

# 3.POST 请求测试
@csrf_exempt
def postTest(request):
    itaem=request.POST['itaem']
    context={'itaem':itaem}
    return render(request, 'booktest/showTest.html', context)

# 4.文件上传测试
def upload(request):
    if request.method == "POST":
        f1 = request.FILES['pic']
        fname = os.path.join(settings.MEDIA_ROOT,f1.name)
        with open(fname, 'wb') as pic:
            for c in f1.chunks():
                pic.write(c)
        return HttpResponse("<img src='/static/media/%s'></img>"%f1.name)
    else:
        return HttpResponse("error")

# 5.分页显示数据
def pagTest(request, pIndex):
    data = HeroInfo.objects.all()
    # 每页数量
    data_size = Paginator(data, 5)
    if pIndex == '':
        pIndex = '1'
    pIndex = int(pIndex)
    # 选页
    data_size_page = data_size.page(pIndex)
    plist = data_size.page_range
    return render(request, 'booktest/showTest.html', {'list': data_size_page, 'plist': plist, 'pIndex': pIndex})

# 6.返回 json 字符串
def getJson(request):
    temp = BookInfo.objects.all()
    data = []
    # 必须全为字典的格式
    for a in temp:
        data.append({'id': a.id, 'title': a.btitle,"bcommet":a.bcommet,"bpub_date":a.bpub_date,"isDelete":a.isDelete,"bread":a.bread})
    return JsonResponse({'data': data})