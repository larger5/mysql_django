from django.apps import AppConfig


class BooktestConfig(AppConfig):
    name = 'booktest'
