from django.contrib import admin
from django.urls import path

from django.conf.urls import url
from booktest import views

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^index$', views.index),
    url(r'^getTest/$', views.getTest),
    url(r'^postTest/$',views.postTest),
    url(r'^upload/$',views.upload),
    url(r'^page/(?P<pIndex>[0-9]*)/$', views.pagTest, name='pagTest'),
    url(r'^getJson/$', views.getJson),
]
